export const password = 'Healgoma9';
export const seed = 'output shop divide often little eager swarm practice quantum actual ritual crush';
export const ethereumEndpoint = 'http://52.170.212.254:8545/';
